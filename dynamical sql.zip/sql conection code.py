import mysql.connector


# ============================================================
# DATABASE CONNECTION
# ============================================================

try:
    db = mysql.connector.connect(
        host="localhost",
        user="shopping_user",
        password="Gayathri",
        database="OnlineShoppingSystem"
    )

    print("MySQL connection successful!")

except mysql.connector.Error as e:
    print("Connection failed:", e)
    exit()


# ============================================================
# CUSTOMER MANAGEMENT
# ============================================================

def customer_management():

    while True:

        print("\n======================================")
        print("        CUSTOMER MANAGEMENT")
        print("======================================")
        print("1. Add Customer")
        print("2. View Customers")
        print("3. Update Customer")
        print("4. Delete Customer")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                customer_id = input("Enter Customer ID: ")
                name = input("Enter customer name: ")
                email = input("Enter customer email: ")
                address = input("Enter customer address: ")
                gender = input("Enter customer gender: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Customer
                    (Customer_ID, Name, Email, Address, Gender)
                    VALUES (%s, %s, %s, %s, %s)
                    """

                    values = (
                        customer_id,
                        name,
                        email,
                        address,
                        gender
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nCustomer added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute("SELECT * FROM Customer")

                    customers = cursor.fetchall()

                    print("\n========== CUSTOMER RECORDS ==========")

                    if len(customers) == 0:

                        print("No customers found.")

                    else:

                        for customer in customers:

                            print(
                                "ID:", customer[0],
                                "| Name:", customer[1],
                                "| Email:", customer[2],
                                "| Address:", customer[3],
                                "| Gender:", customer[4]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                customer_id = input(
                    "Enter Customer ID to update: "
                )

                name = input("Enter new name: ")
                email = input("Enter new email: ")
                address = input("Enter new address: ")
                gender = input("Enter new gender: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Customer
                    SET Name = %s,
                        Email = %s,
                        Address = %s,
                        Gender = %s
                    WHERE Customer_ID = %s
                    """

                    values = (
                        name,
                        email,
                        address,
                        gender,
                        customer_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nCustomer updated successfully!")
                    else:
                        print("\nCustomer ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                customer_id = input(
                    "Enter Customer ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Customer
                        WHERE Customer_ID = %s
                        """,
                        (customer_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nCustomer deleted successfully!")
                    else:
                        print("\nCustomer ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# SELLER MANAGEMENT
# ============================================================

def seller_management():

    while True:

        print("\n======================================")
        print("          SELLER MANAGEMENT")
        print("======================================")
        print("1. Add Seller")
        print("2. View Sellers")
        print("3. Update Seller")
        print("4. Delete Seller")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                seller_id = input("Enter Seller ID: ")
                seller_name = input("Enter seller name: ")
                shop_name = input("Enter shop name: ")
                address = input("Enter seller address: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Seller
                    (Seller_ID, Seller_Name, Shop_Name, Address)
                    VALUES (%s, %s, %s, %s)
                    """

                    values = (
                        seller_id,
                        seller_name,
                        shop_name,
                        address
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nSeller added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute("SELECT * FROM Seller")

                    sellers = cursor.fetchall()

                    print("\n========== SELLER RECORDS ==========")

                    if len(sellers) == 0:

                        print("No sellers found.")

                    else:

                        for seller in sellers:

                            print(
                                "Seller ID:", seller[0],
                                "| Seller Name:", seller[1],
                                "| Shop Name:", seller[2],
                                "| Address:", seller[3]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                seller_id = input(
                    "Enter Seller ID to update: "
                )

                seller_name = input("Enter new seller name: ")
                shop_name = input("Enter new shop name: ")
                address = input("Enter new address: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Seller
                    SET Seller_Name = %s,
                        Shop_Name = %s,
                        Address = %s
                    WHERE Seller_ID = %s
                    """

                    values = (
                        seller_name,
                        shop_name,
                        address,
                        seller_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nSeller updated successfully!")
                    else:
                        print("\nSeller ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                seller_id = input(
                    "Enter Seller ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Seller
                        WHERE Seller_ID = %s
                        """,
                        (seller_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nSeller deleted successfully!")
                    else:
                        print("\nSeller ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# CATEGORY MANAGEMENT
# ============================================================

def category_management():

    while True:

        print("\n======================================")
        print("         CATEGORY MANAGEMENT")
        print("======================================")
        print("1. Add Category")
        print("2. View Categories")
        print("3. Update Category")
        print("4. Delete Category")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                category_id = input("Enter Category ID: ")
                description = input(
                    "Enter category description: "
                )
                status = input("Enter category status: ")
                category_name = input(
                    "Enter category name: "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Category
                    (Category_ID, Description, Status, Category_Name)
                    VALUES (%s, %s, %s, %s)
                    """

                    values = (
                        category_id,
                        description,
                        status,
                        category_name
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nCategory added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute("SELECT * FROM Category")

                    categories = cursor.fetchall()

                    print("\n========== CATEGORY RECORDS ==========")

                    if len(categories) == 0:

                        print("No categories found.")

                    else:

                        for category in categories:

                            print(
                                "Category ID:", category[0],
                                "| Description:", category[1],
                                "| Status:", category[2],
                                "| Name:", category[3]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                category_id = input(
                    "Enter Category ID to update: "
                )

                description = input(
                    "Enter new description: "
                )
                status = input("Enter new status: ")
                category_name = input(
                    "Enter new category name: "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Category
                    SET Description = %s,
                        Status = %s,
                        Category_Name = %s
                    WHERE Category_ID = %s
                    """

                    values = (
                        description,
                        status,
                        category_name,
                        category_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nCategory updated successfully!")
                    else:
                        print("\nCategory ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                category_id = input(
                    "Enter Category ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Category
                        WHERE Category_ID = %s
                        """,
                        (category_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nCategory deleted successfully!")
                    else:
                        print("\nCategory ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# PRODUCT MANAGEMENT
# ============================================================

def product_management():

    while True:

        print("\n======================================")
        print("          PRODUCT MANAGEMENT")
        print("======================================")
        print("1. Add Product")
        print("2. View Products")
        print("3. Update Product")
        print("4. Delete Product")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                product_id = input("Enter Product ID: ")
                seller_id = input("Enter Seller ID: ")
                category_id = input("Enter Category ID: ")
                product_name = input("Enter product name: ")
                brand = input("Enter brand: ")
                price = input("Enter price: ")
                stock_quantity = input(
                    "Enter stock quantity: "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Product
                    (
                        Product_ID,
                        Seller_ID,
                        Category_ID,
                        Product_Name,
                        Brand,
                        Price,
                        Stock_Quantity
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """

                    values = (
                        product_id,
                        seller_id,
                        category_id,
                        product_name,
                        brand,
                        price,
                        stock_quantity
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nProduct added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute("SELECT * FROM Product")

                    products = cursor.fetchall()

                    print("\n========== PRODUCT RECORDS ==========")

                    if len(products) == 0:

                        print("No products found.")

                    else:

                        for product in products:

                            print(
                                "Product ID:", product[0],
                                "| Seller ID:", product[1],
                                "| Category ID:", product[2],
                                "| Product Name:", product[3],
                                "| Brand:", product[4],
                                "| Price:", product[5],
                                "| Stock:", product[6]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                product_id = input(
                    "Enter Product ID to update: "
                )

                seller_id = input("Enter new Seller ID: ")
                category_id = input(
                    "Enter new Category ID: "
                )
                product_name = input(
                    "Enter new product name: "
                )
                brand = input("Enter new brand: ")
                price = input("Enter new price: ")
                stock_quantity = input(
                    "Enter new stock quantity: "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Product
                    SET Seller_ID = %s,
                        Category_ID = %s,
                        Product_Name = %s,
                        Brand = %s,
                        Price = %s,
                        Stock_Quantity = %s
                    WHERE Product_ID = %s
                    """

                    values = (
                        seller_id,
                        category_id,
                        product_name,
                        brand,
                        price,
                        stock_quantity,
                        product_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nProduct updated successfully!")
                    else:
                        print("\nProduct ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                product_id = input(
                    "Enter Product ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Product
                        WHERE Product_ID = %s
                        """,
                        (product_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nProduct deleted successfully!")
                    else:
                        print("\nProduct ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# SHOPPING CART
# ============================================================

def shopping_cart():

    while True:

        print("\n======================================")
        print("          SHOPPING CART")
        print("======================================")
        print("1. Add Cart")
        print("2. View Cart")
        print("3. Update Cart")
        print("4. Delete Cart")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                cart_id = input("Enter Cart ID: ")
                customer_id = input("Enter Customer ID: ")
                product_id = input("Enter Product ID: ")
                quantity = input("Enter quantity: ")
                total_price = input("Enter total price: ")
                cart_status = input("Enter cart status: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO cart
                    (
                        Cart_ID,
                        Customer_ID,
                        Product_ID,
                        Quantity,
                        Total_Price,
                        Cart_Status
                    )
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """

                    values = (
                        cart_id,
                        customer_id,
                        product_id,
                        quantity,
                        total_price,
                        cart_status
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nCart added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute("SELECT * FROM cart")

                    carts = cursor.fetchall()

                    print("\n========== CART RECORDS ==========")

                    if len(carts) == 0:

                        print("No cart records found.")

                    else:

                        for cart in carts:

                            print(
                                "Cart ID:", cart[0],
                                "| Customer ID:", cart[1],
                                "| Product ID:", cart[2],
                                "| Quantity:", cart[3],
                                "| Total Price:", cart[4],
                                "| Status:", cart[5]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                cart_id = input(
                    "Enter Cart ID to update: "
                )

                customer_id = input(
                    "Enter new Customer ID: "
                )
                product_id = input(
                    "Enter new Product ID: "
                )
                quantity = input("Enter new quantity: ")
                total_price = input(
                    "Enter new total price: "
                )
                cart_status = input(
                    "Enter new cart status: "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE cart
                    SET Customer_ID = %s,
                        Product_ID = %s,
                        Quantity = %s,
                        Total_Price = %s,
                        Cart_Status = %s
                    WHERE Cart_ID = %s
                    """

                    values = (
                        customer_id,
                        product_id,
                        quantity,
                        total_price,
                        cart_status,
                        cart_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nCart updated successfully!")
                    else:
                        print("\nCart ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                cart_id = input(
                    "Enter Cart ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM cart
                        WHERE Cart_ID = %s
                        """,
                        (cart_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nCart deleted successfully!")
                    else:
                        print("\nCart ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# ORDER MANAGEMENT
# ============================================================

def order_management():

    while True:

        print("\n======================================")
        print("          ORDER MANAGEMENT")
        print("======================================")
        print("1. Add Order")
        print("2. View Orders")
        print("3. Update Order")
        print("4. Delete Order")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                order_id = input("Enter Order ID: ")
                customer_id = input("Enter Customer ID: ")
                order_date = input(
                    "Enter order date (YYYY-MM-DD): "
                )
                total_amount = input(
                    "Enter total amount: "
                )
                shipping_status = input(
                    "Enter shipping status: "
                )
                delivery_date = input(
                    "Enter delivery date (YYYY-MM-DD): "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Orders
                    (
                        Order_ID,
                        Customer_ID,
                        Order_Date,
                        Total_Amount,
                        Shipping_Status,
                        Delivery_Date
                    )
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """

                    values = (
                        order_id,
                        customer_id,
                        order_date,
                        total_amount,
                        shipping_status,
                        delivery_date
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nOrder added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        "SELECT * FROM Orders"
                    )

                    orders = cursor.fetchall()

                    print("\n========== ORDER RECORDS ==========")

                    if len(orders) == 0:

                        print("No orders found.")

                    else:

                        for order in orders:

                            print(
                                "Order ID:", order[0],
                                "| Customer ID:", order[1],
                                "| Order Date:", order[2],
                                "| Total Amount:", order[3],
                                "| Shipping Status:", order[4],
                                "| Delivery Date:", order[5]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                order_id = input(
                    "Enter Order ID to update: "
                )

                customer_id = input(
                    "Enter new Customer ID: "
                )
                order_date = input(
                    "Enter new order date (YYYY-MM-DD): "
                )
                total_amount = input(
                    "Enter new total amount: "
                )
                shipping_status = input(
                    "Enter new shipping status: "
                )
                delivery_date = input(
                    "Enter new delivery date (YYYY-MM-DD): "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Orders
                    SET Customer_ID = %s,
                        Order_Date = %s,
                        Total_Amount = %s,
                        Shipping_Status = %s,
                        Delivery_Date = %s
                    WHERE Order_ID = %s
                    """

                    values = (
                        customer_id,
                        order_date,
                        total_amount,
                        shipping_status,
                        delivery_date,
                        order_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nOrder updated successfully!")
                    else:
                        print("\nOrder ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                order_id = input(
                    "Enter Order ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Orders
                        WHERE Order_ID = %s
                        """,
                        (order_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nOrder deleted successfully!")
                    else:
                        print("\nOrder ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# PAYMENT MANAGEMENT
# ============================================================

def payment_management():

    while True:

        print("\n======================================")
        print("          PAYMENT MANAGEMENT")
        print("======================================")
        print("1. Add Payment")
        print("2. View Payments")
        print("3. Update Payment")
        print("4. Delete Payment")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                payment_id = input("Enter Payment ID: ")
                order_id = input("Enter Order ID: ")
                payment_date = input(
                    "Enter payment date (YYYY-MM-DD): "
                )
                amount = input("Enter payment amount: ")
                bank_name = input("Enter bank name: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Payment
                    (
                        Payment_ID,
                        Order_ID,
                        Payment_Date,
                        Amount,
                        Bank_Name
                    )
                    VALUES (%s, %s, %s, %s, %s)
                    """

                    values = (
                        payment_id,
                        order_id,
                        payment_date,
                        amount,
                        bank_name
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nPayment added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        "SELECT * FROM Payment"
                    )

                    payments = cursor.fetchall()

                    print("\n========== PAYMENT RECORDS ==========")

                    if len(payments) == 0:

                        print("No payments found.")

                    else:

                        for payment in payments:

                            print(
                                "Payment ID:", payment[0],
                                "| Order ID:", payment[1],
                                "| Payment Date:", payment[2],
                                "| Amount:", payment[3],
                                "| Bank Name:", payment[4]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                payment_id = input(
                    "Enter Payment ID to update: "
                )

                order_id = input(
                    "Enter new Order ID: "
                )
                payment_date = input(
                    "Enter new payment date (YYYY-MM-DD): "
                )
                amount = input(
                    "Enter new payment amount: "
                )
                bank_name = input(
                    "Enter new bank name: "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Payment
                    SET Order_ID = %s,
                        Payment_Date = %s,
                        Amount = %s,
                        Bank_Name = %s
                    WHERE Payment_ID = %s
                    """

                    values = (
                        order_id,
                        payment_date,
                        amount,
                        bank_name,
                        payment_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nPayment updated successfully!")
                    else:
                        print("\nPayment ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                payment_id = input(
                    "Enter Payment ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Payment
                        WHERE Payment_ID = %s
                        """,
                        (payment_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nPayment deleted successfully!")
                    else:
                        print("\nPayment ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# SHIPPING MANAGEMENT
# ============================================================

def shipping_management():

    while True:

        print("\n======================================")
        print("          SHIPPING MANAGEMENT")
        print("======================================")
        print("1. Add Shipping")
        print("2. View Shipping")
        print("3. Update Shipping")
        print("4. Delete Shipping")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                shipping_id = input(
                    "Enter Shipping ID: "
                )
                order_id = input(
                    "Enter Order ID: "
                )
                shipping_address = input(
                    "Enter shipping address: "
                )
                delivery_date = input(
                    "Enter delivery date (YYYY-MM-DD): "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Shipping
                    (
                        Shipping_ID,
                        Order_ID,
                        Shipping_Address,
                        Delivery_Date
                    )
                    VALUES (%s, %s, %s, %s)
                    """

                    values = (
                        shipping_id,
                        order_id,
                        shipping_address,
                        delivery_date
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nShipping added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        "SELECT * FROM Shipping"
                    )

                    records = cursor.fetchall()

                    print("\n========== SHIPPING RECORDS ==========")

                    if len(records) == 0:

                        print("No shipping records found.")

                    else:

                        for shipping in records:

                            print(
                                "Shipping ID:", shipping[0],
                                "| Order ID:", shipping[1],
                                "| Address:", shipping[2],
                                "| Delivery Date:", shipping[3]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                shipping_id = input(
                    "Enter Shipping ID to update: "
                )

                order_id = input(
                    "Enter new Order ID: "
                )
                shipping_address = input(
                    "Enter new shipping address: "
                )
                delivery_date = input(
                    "Enter new delivery date (YYYY-MM-DD): "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Shipping
                    SET Order_ID = %s,
                        Shipping_Address = %s,
                        Delivery_Date = %s
                    WHERE Shipping_ID = %s
                    """

                    values = (
                        order_id,
                        shipping_address,
                        delivery_date,
                        shipping_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nShipping updated successfully!")
                    else:
                        print("\nShipping ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                shipping_id = input(
                    "Enter Shipping ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Shipping
                        WHERE Shipping_ID = %s
                        """,
                        (shipping_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nShipping deleted successfully!")
                    else:
                        print("\nShipping ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# REVIEW MANAGEMENT
# ============================================================

def review_management():

    while True:

        print("\n======================================")
        print("          REVIEW MANAGEMENT")
        print("======================================")
        print("1. Add Review")
        print("2. View Reviews")
        print("3. Update Review")
        print("4. Delete Review")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                review_id = input("Enter Review ID: ")
                customer_id = input("Enter Customer ID: ")
                product_id = input("Enter Product ID: ")
                rating = input("Enter rating (1-5): ")
                review_text = input("Enter review text: ")
                review_date = input(
                    "Enter review date (YYYY-MM-DD): "
                )
                status = input("Enter review status: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Review
                    (
                        Review_ID,
                        Customer_ID,
                        Product_ID,
                        Rating,
                        Review_Text,
                        Review_Date,
                        Status
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """

                    values = (
                        review_id,
                        customer_id,
                        product_id,
                        rating,
                        review_text,
                        review_date,
                        status
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nReview added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        "SELECT * FROM Review"
                    )

                    reviews = cursor.fetchall()

                    print("\n========== REVIEW RECORDS ==========")

                    if len(reviews) == 0:

                        print("No reviews found.")

                    else:

                        for review in reviews:

                            print(
                                "Review ID:", review[0],
                                "| Customer ID:", review[1],
                                "| Product ID:", review[2],
                                "| Rating:", review[3],
                                "| Review:", review[4],
                                "| Date:", review[5],
                                "| Status:", review[6]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                review_id = input(
                    "Enter Review ID to update: "
                )

                customer_id = input(
                    "Enter new Customer ID: "
                )
                product_id = input(
                    "Enter new Product ID: "
                )
                rating = input(
                    "Enter new rating (1-5): "
                )
                review_text = input(
                    "Enter new review text: "
                )
                review_date = input(
                    "Enter new review date (YYYY-MM-DD): "
                )
                status = input(
                    "Enter new review status: "
                )

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Review
                    SET Customer_ID = %s,
                        Product_ID = %s,
                        Rating = %s,
                        Review_Text = %s,
                        Review_Date = %s,
                        Status = %s
                    WHERE Review_ID = %s
                    """

                    values = (
                        customer_id,
                        product_id,
                        rating,
                        review_text,
                        review_date,
                        status,
                        review_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nReview updated successfully!")
                    else:
                        print("\nReview ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                review_id = input(
                    "Enter Review ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Review
                        WHERE Review_ID = %s
                        """,
                        (review_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nReview deleted successfully!")
                    else:
                        print("\nReview ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# ADMIN MANAGEMENT
# ============================================================

def admin_management():

    while True:

        print("\n======================================")
        print("          ADMIN MANAGEMENT")
        print("======================================")
        print("1. Add Admin")
        print("2. View Admins")
        print("3. Update Admin")
        print("4. Delete Admin")
        print("5. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            case "1":

                admin_id = input("Enter Admin ID: ")
                name = input("Enter admin name: ")
                email = input("Enter admin email: ")
                username = input("Enter admin username: ")
                role = input("Enter admin role: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    INSERT INTO Admin
                    (
                        Admin_ID,
                        Name,
                        Email,
                        Username,
                        Role
                    )
                    VALUES (%s, %s, %s, %s, %s)
                    """

                    values = (
                        admin_id,
                        name,
                        email,
                        username,
                        role
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    print("\nAdmin added successfully!")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "2":

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        "SELECT * FROM Admin"
                    )

                    admins = cursor.fetchall()

                    print("\n========== ADMIN RECORDS ==========")

                    if len(admins) == 0:

                        print("No admins found.")

                    else:

                        for admin in admins:

                            print(
                                "Admin ID:", admin[0],
                                "| Name:", admin[1],
                                "| Email:", admin[2],
                                "| Username:", admin[3],
                                "| Role:", admin[4]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "3":

                admin_id = input(
                    "Enter Admin ID to update: "
                )

                name = input("Enter new admin name: ")
                email = input("Enter new admin email: ")
                username = input("Enter new username: ")
                role = input("Enter new role: ")

                try:

                    cursor = db.cursor()

                    sql = """
                    UPDATE Admin
                    SET Name = %s,
                        Email = %s,
                        Username = %s,
                        Role = %s
                    WHERE Admin_ID = %s
                    """

                    values = (
                        name,
                        email,
                        username,
                        role,
                        admin_id
                    )

                    cursor.execute(sql, values)
                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nAdmin updated successfully!")
                    else:
                        print("\nAdmin ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "4":

                admin_id = input(
                    "Enter Admin ID to delete: "
                )

                try:

                    cursor = db.cursor()

                    cursor.execute(
                        """
                        DELETE FROM Admin
                        WHERE Admin_ID = %s
                        """,
                        (admin_id,)
                    )

                    db.commit()

                    if cursor.rowcount > 0:
                        print("\nAdmin deleted successfully!")
                    else:
                        print("\nAdmin ID not found.")

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "5":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# SQL REPORTS AND JOIN QUERIES
# ============================================================

def reports():

    while True:

        print("\n======================================")
        print("          SQL REPORTS")
        print("======================================")
        print("1. Customer Order Report")
        print("2. Order Payment Report")
        print("3. Order Shipping Report")
        print("4. Product Seller Category Report")
        print("5. Customer Review Product Report")
        print("6. Complete Order Report")
        print("7. Back to Main Menu")
        print("======================================")

        choice = input("Enter your choice: ")

        match choice:

            # ------------------------------------------------
            # REPORT 1
            # ------------------------------------------------

            case "1":

                try:

                    cursor = db.cursor()

                    sql = """
                    SELECT
                        c.Customer_ID,
                        c.Name,
                        o.Order_ID,
                        o.Order_Date,
                        o.Total_Amount,
                        o.Shipping_Status
                    FROM Customer c
                    JOIN Orders o
                    ON c.Customer_ID = o.Customer_ID
                    """

                    cursor.execute(sql)

                    records = cursor.fetchall()

                    print("\n========== CUSTOMER ORDER REPORT ==========")

                    if len(records) == 0:

                        print("No records found.")

                    else:

                        for row in records:

                            print(
                                "Customer ID:", row[0],
                                "| Customer:", row[1],
                                "| Order ID:", row[2],
                                "| Order Date:", row[3],
                                "| Amount:", row[4],
                                "| Status:", row[5]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            # ------------------------------------------------
            # REPORT 2
            # ------------------------------------------------

            case "2":

                try:

                    cursor = db.cursor()

                    sql = """
                    SELECT
                        o.Order_ID,
                        o.Order_Date,
                        o.Total_Amount,
                        p.Payment_ID,
                        p.Payment_Date,
                        p.Amount,
                        p.Bank_Name
                    FROM Orders o
                    JOIN Payment p
                    ON o.Order_ID = p.Order_ID
                    """

                    cursor.execute(sql)

                    records = cursor.fetchall()

                    print("\n========== ORDER PAYMENT REPORT ==========")

                    if len(records) == 0:

                        print("No records found.")

                    else:

                        for row in records:

                            print(
                                "Order ID:", row[0],
                                "| Order Date:", row[1],
                                "| Order Amount:", row[2],
                                "| Payment ID:", row[3],
                                "| Payment Date:", row[4],
                                "| Paid Amount:", row[5],
                                "| Bank:", row[6]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            # ------------------------------------------------
            # REPORT 3
            # ------------------------------------------------

            case "3":

                try:

                    cursor = db.cursor()

                    sql = """
                    SELECT
                        o.Order_ID,
                        o.Shipping_Status,
                        s.Shipping_ID,
                        s.Shipping_Address,
                        s.Delivery_Date
                    FROM Orders o
                    JOIN Shipping s
                    ON o.Order_ID = s.Order_ID
                    """

                    cursor.execute(sql)

                    records = cursor.fetchall()

                    print("\n========== ORDER SHIPPING REPORT ==========")

                    if len(records) == 0:

                        print("No records found.")

                    else:

                        for row in records:

                            print(
                                "Order ID:", row[0],
                                "| Shipping Status:", row[1],
                                "| Shipping ID:", row[2],
                                "| Address:", row[3],
                                "| Delivery Date:", row[4]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            # ------------------------------------------------
            # REPORT 4
            # ------------------------------------------------

            case "4":

                try:

                    cursor = db.cursor()

                    sql = """
                    SELECT
                        p.Product_ID,
                        p.Product_Name,
                        p.Brand,
                        p.Price,
                        s.Seller_Name,
                        s.Shop_Name,
                        c.Category_Name
                    FROM Product p
                    JOIN Seller s
                    ON p.Seller_ID = s.Seller_ID
                    JOIN Category c
                    ON p.Category_ID = c.Category_ID
                    """

                    cursor.execute(sql)

                    records = cursor.fetchall()

                    print(
                        "\n========== PRODUCT SELLER CATEGORY REPORT =========="
                    )

                    if len(records) == 0:

                        print("No records found.")

                    else:

                        for row in records:

                            print(
                                "Product ID:", row[0],
                                "| Product:", row[1],
                                "| Brand:", row[2],
                                "| Price:", row[3],
                                "| Seller:", row[4],
                                "| Shop:", row[5],
                                "| Category:", row[6]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            # ------------------------------------------------
            # REPORT 5
            # ------------------------------------------------

            case "5":

                try:

                    cursor = db.cursor()

                    sql = """
                    SELECT
                        c.Customer_ID,
                        c.Name,
                        p.Product_ID,
                        p.Product_Name,
                        r.Review_ID,
                        r.Rating,
                        r.Review_Text,
                        r.Review_Date,
                        r.Status
                    FROM Customer c
                    JOIN Review r
                    ON c.Customer_ID = r.Customer_ID
                    JOIN Product p
                    ON r.Product_ID = p.Product_ID
                    """

                    cursor.execute(sql)

                    records = cursor.fetchall()

                    print(
                        "\n========== CUSTOMER REVIEW PRODUCT REPORT =========="
                    )

                    if len(records) == 0:

                        print("No records found.")

                    else:

                        for row in records:

                            print(
                                "Customer ID:", row[0],
                                "| Customer:", row[1],
                                "| Product ID:", row[2],
                                "| Product:", row[3],
                                "| Review ID:", row[4],
                                "| Rating:", row[5],
                                "| Review:", row[6],
                                "| Date:", row[7],
                                "| Status:", row[8]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            # ------------------------------------------------
            # REPORT 6
            # ------------------------------------------------

            case "6":

                try:

                    cursor = db.cursor()

                    sql = """
                    SELECT
                        c.Customer_ID,
                        c.Name AS Customer_Name,

                        o.Order_ID,
                        o.Order_Date,
                        o.Total_Amount,
                        o.Shipping_Status,

                        p.Payment_ID,
                        p.Payment_Date,
                        p.Amount AS Payment_Amount,
                        p.Bank_Name,

                        s.Shipping_ID,
                        s.Shipping_Address,
                        s.Delivery_Date

                    FROM Customer c

                    JOIN Orders o
                    ON c.Customer_ID = o.Customer_ID

                    LEFT JOIN Payment p
                    ON o.Order_ID = p.Order_ID

                    LEFT JOIN Shipping s
                    ON o.Order_ID = s.Order_ID
                    """

                    cursor.execute(sql)

                    records = cursor.fetchall()

                    print(
                        "\n========== COMPLETE ORDER REPORT =========="
                    )

                    if len(records) == 0:

                        print("No records found.")

                    else:

                        for row in records:

                            print(
                                "\nCustomer ID:", row[0],
                                "| Customer:", row[1],
                                "| Order ID:", row[2],
                                "| Order Date:", row[3],
                                "| Total:", row[4],
                                "| Shipping Status:", row[5],
                                "| Payment ID:", row[6],
                                "| Payment Date:", row[7],
                                "| Payment Amount:", row[8],
                                "| Bank:", row[9],
                                "| Shipping ID:", row[10],
                                "| Address:", row[11],
                                "| Delivery:", row[12]
                            )

                    cursor.close()

                except mysql.connector.Error as e:
                    print("\nError:", e)


            case "7":

                break


            case _:

                print("\nInvalid choice.")


# ============================================================
# MAIN MENU
# ============================================================

while True:

    print("\n")
    print("================================================")
    print("          ONLINE SHOPPING SYSTEM")
    print("================================================")
    print("1.  Customer Management")
    print("2.  Seller Management")
    print("3.  Category Management")
    print("4.  Product Management")
    print("5.  Shopping Cart")
    print("6.  Order Management")
    print("7.  Payment Management")
    print("8.  Shipping Management")
    print("9.  Review Management")
    print("10. Admin Management")
    print("11. SQL Reports")
    print("12. Exit")
    print("================================================")

    choice = input("Enter your choice: ")

    match choice:

        case "1":
            customer_management()

        case "2":
            seller_management()

        case "3":
            category_management()

        case "4":
            product_management()

        case "5":
            shopping_cart()

        case "6":
            order_management()

        case "7":
            payment_management()

        case "8":
            shipping_management()

        case "9":
            review_management()

        case "10":
            admin_management()

        case "11":
            reports()

        case "12":

            print(
                "\nThank you for using "
                "Online Shopping System!"
            )

            break

        case _:

            print(
                "\nInvalid choice."
                " Please enter a number from 1 to 12."
            )


# ============================================================
# CLOSE DATABASE
# ============================================================

db.close()

print("\nDatabase connection closed.")