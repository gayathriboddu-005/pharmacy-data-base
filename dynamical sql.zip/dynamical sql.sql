CREATE DATABASE OnlineShoppingSystem;
USE OnlineShoppingSystem;
SELECT DATABASE();

-- 1. CUSTOMER TABLE
CREATE TABLE Customer (
    Customer_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100),
    Address VARCHAR(200),
    Gender VARCHAR(10)
);

-- 2. SELLER TABLE
CREATE TABLE Seller (
    Seller_ID INT PRIMARY KEY AUTO_INCREMENT,
    Seller_Name VARCHAR(100) NOT NULL,
    Shop_Name VARCHAR(100),
    Address VARCHAR(200)
);

-- 3. CATEGORY TABLE
CREATE TABLE Category (
    Category_ID INT PRIMARY KEY AUTO_INCREMENT,
    Category_Name VARCHAR(100) NOT NULL,
    Description VARCHAR(255),
    Status VARCHAR(20)
);

-- 4. PRODUCT TABLE
CREATE TABLE Product (
    Product_ID INT PRIMARY KEY AUTO_INCREMENT,
    Seller_ID INT,
    Category_ID INT,
    Product_Name VARCHAR(100) NOT NULL,
    Brand VARCHAR(100),
    Price DECIMAL(10,2),
    Stock_Quantity INT,
    FOREIGN KEY (Seller_ID)
        REFERENCES Seller(Seller_ID),
    FOREIGN KEY (Category_ID)
        REFERENCES Category(Category_ID)
);

-- 5. SHOPPING CART TABLE
CREATE TABLE ShoppingCart (
    Cart_ID INT PRIMARY KEY AUTO_INCREMENT,
    Customer_ID INT,
    Product_ID INT,
    Quantity INT,
    Total_Price DECIMAL(10,2),
    Cart_Status VARCHAR(30),
    FOREIGN KEY (Customer_ID)
        REFERENCES Customer(Customer_ID),
    FOREIGN KEY (Product_ID)
        REFERENCES Product(Product_ID)
);
-- 6. ORDER TABLE
CREATE TABLE Orders (
    Order_ID INT PRIMARY KEY AUTO_INCREMENT,
    Customer_ID INT,
    Order_Date DATE,
    Total_Amount DECIMAL(10,2),
    Shipping_Status VARCHAR(30),
    Delivery_Date DATE,
    FOREIGN KEY (Customer_ID)
        REFERENCES Customer(Customer_ID)
);

-- 7. PAYMENT TABLE
CREATE TABLE Payment (
    Payment_ID INT PRIMARY KEY AUTO_INCREMENT,
    Order_ID INT,
    Payment_Date DATE,
    Amount DECIMAL(10,2),
    Bank_Name VARCHAR(100),
    FOREIGN KEY (Order_ID)
        REFERENCES Orders(Order_ID)
);

-- 8. SHIPPING TABLE
CREATE TABLE Shipping (
    Shipping_ID INT PRIMARY KEY AUTO_INCREMENT,
    Order_ID INT,
    Shipping_Address VARCHAR(200),
    Delivery_Date DATE,
    FOREIGN KEY (Order_ID)
        REFERENCES Orders(Order_ID)
);

-- 9. REVIEW TABLE
CREATE TABLE Review (
    Review_ID INT PRIMARY KEY AUTO_INCREMENT,
    Customer_ID INT,
    Product_ID INT,
    Rating INT,
    Review_Text VARCHAR(500),
    Review_Date DATE,
    Status VARCHAR(20),
    FOREIGN KEY (Customer_ID)
        REFERENCES Customer(Customer_ID),
    FOREIGN KEY (Product_ID)
        REFERENCES Product(Product_ID)
);

-- 10. ADMIN TABLE
CREATE TABLE Admin (
    Admin_ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Username VARCHAR(50),
    Role VARCHAR(50)
);
SHOW TABLES;
DESCRIBE Customer;
DESCRIBE Seller;
DESCRIBE Category;
DESCRIBE Product;
DESCRIBE ShoppingCart;
DESCRIBE Orders;
DESCRIBE Payment;
DESCRIBE Shipping;
DESCRIBE Review;
DESCRIBE Admin;

USE OnlineShoppingSystem;


-- ============================================================
-- 53. NORMALIZATION - FIRST NORMAL FORM (1NF)
-- ============================================================

-- 1NF requires:
-- 1. Atomic values
-- 2. No repeating groups
-- 3. Each row should be uniquely identifiable


-- CUSTOMER TABLE

SELECT
    Customer_ID,
    Name,
    Email,
    Address,
    Gender
FROM Customer;


-- PRODUCT TABLE

SELECT
    Product_ID,
    Product_Name,
    Brand,
    Price,
    Stock_Quantity
FROM Product;


-- SELLER TABLE

SELECT
    Seller_ID,
    Seller_Name,
    Shop_Name,
    Address
FROM Seller;


-- CATEGORY TABLE

SELECT
    Category_ID,
    Category_Name,
    Description,
    Status
FROM Category;



-- ============================================================
-- 54. NORMALIZATION - SECOND NORMAL FORM (2NF)
-- ============================================================

-- 2NF requires:
-- 1. Table must be in 1NF
-- 2. Non-key attributes must depend on the complete primary key


-- PRODUCT

SELECT
    Product_ID,
    Product_Name,
    Brand,
    Price,
    Stock_Quantity
FROM Product;


-- SELLER

SELECT
    Seller_ID,
    Seller_Name,
    Shop_Name,
    Address
FROM Seller;


-- CATEGORY

SELECT
    Category_ID,
    Category_Name,
    Description,
    Status
FROM Category;


-- CUSTOMER

SELECT
    Customer_ID,
    Name,
    Email,
    Address,
    Gender
FROM Customer;



-- ============================================================
-- 55. NORMALIZATION - THIRD NORMAL FORM (3NF)
-- ============================================================

-- 3NF requires:
-- 1. Table must be in 2NF
-- 2. No transitive dependency
-- 3. Non-key attributes depend only on the primary key


-- PRODUCT -> SELLER -> CATEGORY

SELECT
    p.Product_ID,
    p.Product_Name,
    p.Brand,
    p.Price,
    p.Stock_Quantity,
    s.Seller_Name,
    s.Shop_Name,
    c.Category_Name
FROM Product p
JOIN Seller s
    ON p.Seller_ID = s.Seller_ID
JOIN Category c
    ON p.Category_ID = c.Category_ID;



-- ============================================================
-- 56. NORMALIZED TABLE RELATIONSHIPS
-- ============================================================


-- ------------------------------------------------------------
-- CUSTOMER -> ORDERS
-- ------------------------------------------------------------

SELECT
    c.Customer_ID,
    c.Name,
    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    o.Shipping_Status,
    o.Delivery_Date
FROM Customer c
JOIN Orders o
    ON c.Customer_ID = o.Customer_ID;



-- ------------------------------------------------------------
-- ORDERS -> PAYMENT
-- ------------------------------------------------------------

SELECT
    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    p.Payment_ID,
    p.Payment_Date,
    p.Amount,
    p.Bank_Name
FROM Orders o
JOIN Payment p
    ON o.Order_ID = p.Order_ID;



-- ------------------------------------------------------------
-- ORDERS -> SHIPPING
-- ------------------------------------------------------------

SELECT
    o.Order_ID,
    o.Shipping_Status,
    s.Shipping_ID,
    s.Shipping_Address,
    s.Delivery_Date
FROM Orders o
JOIN Shipping s
    ON o.Order_ID = s.Order_ID;



-- ------------------------------------------------------------
-- PRODUCT -> SELLER -> CATEGORY
-- ------------------------------------------------------------

SELECT
    p.Product_ID,
    p.Product_Name,
    p.Brand,
    p.Price,
    s.Seller_ID,
    s.Seller_Name,
    s.Shop_Name,
    c.Category_ID,
    c.Category_Name
FROM Product p
JOIN Seller s
    ON p.Seller_ID = s.Seller_ID
JOIN Category c
    ON p.Category_ID = c.Category_ID;



-- ------------------------------------------------------------
-- CUSTOMER -> REVIEW -> PRODUCT
-- ------------------------------------------------------------

SELECT
    c.Customer_ID,
    c.Name,
    p.Product_ID,
    p.Product_Name,
    r.Review_ID,
    r.Rating,
    r.Review_Text,
    r.Review_Date,
    r.Status
FROM Customer c
JOIN Review r
    ON c.Customer_ID = r.Customer_ID
JOIN Product p
    ON r.Product_ID = p.Product_ID;


-- SQL REPORTS

-- Customer → Orders
SELECT
    c.Customer_ID,
    c.Name AS Customer_Name,
    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    o.Shipping_Status
FROM Customer c
JOIN Orders o
    ON c.Customer_ID = o.Customer_ID;
    
-- Product → Seller → Category
SELECT
    p.Product_ID,
    p.Product_Name,
    s.Seller_Name,
    s.Shop_Name,
    c.Category_Name,
    p.Price,
    p.Stock_Quantity
FROM Product p
JOIN Seller s
    ON p.Seller_ID = s.Seller_ID
JOIN Category c
    ON p.Category_ID = c.Category_ID;
    
-- Orders → Payment
SELECT
    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    p.Payment_ID,
    p.Payment_Date,
    p.Amount,
    p.Bank_Name
FROM Orders o
JOIN Payment p
    ON o.Order_ID = p.Order_ID;
    
-- Orders → Shipping
SELECT
    o.Order_ID,
    o.Order_Date,
    o.Shipping_Status,
    s.Shipping_ID,
    s.Shipping_Address,
    s.Delivery_Date
FROM Orders o
JOIN Shipping s
    ON o.Order_ID = s.Order_ID;
    
-- Customer → Shopping Cart → Product
SELECT
    c.Customer_ID,
    c.Name AS Customer_Name,
    sc.Cart_ID,
    p.Product_ID,
    p.Product_Name,
    sc.Quantity,
    sc.Total_Price,
    sc.Cart_Status
FROM Customer c
JOIN shoppingcart sc
    ON c.Customer_ID = sc.Customer_ID
JOIN Product p
    ON sc.Product_ID = p.Product_ID;

-- Customer → Review → Product
SELECT
    c.Customer_ID,
    c.Name AS Customer_Name,
    p.Product_ID,
    p.Product_Name,
    r.Review_ID,
    r.Rating,
    r.Review_Text,
    r.Review_Date
FROM Customer c
JOIN Review r
    ON c.Customer_ID = r.Customer_ID
JOIN Product p
    ON r.Product_ID = p.Product_ID;
    
-- Customer → Orders → Payment → Shipping
SELECT
    c.Name AS Customer_Name,
    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    o.Shipping_Status,
    p.Payment_ID,
    p.Amount AS Payment_Amount,
    p.Bank_Name,
    s.Shipping_Address,
    s.Delivery_Date
FROM Customer c
JOIN Orders o
    ON c.Customer_ID = o.Customer_ID
LEFT JOIN Payment p
    ON o.Order_ID = p.Order_ID
LEFT JOIN Shipping s
    ON o.Order_ID = s.Order_ID;
    
-- Product → Seller → Category
SELECT
    p.Product_ID,
    p.Product_Name,
    s.Seller_Name,
    s.Shop_Name,
    c.Category_Name,
    p.Brand,
    p.Price,
    p.Stock_Quantity
FROM Product p
JOIN Seller s
    ON p.Seller_ID = s.Seller_ID
JOIN Category c
    ON p.Category_ID = c.Category_ID;
    
-- Orders → Payment.
SELECT
    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    p.Payment_ID,
    p.Payment_Date,
    p.Amount,
    p.Bank_Name
FROM Orders o
JOIN Payment p
    ON o.Order_ID = p.Order_ID;
    
-- Orders → Shipping
SELECT
    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    o.Shipping_Status,
    s.Shipping_ID,
    s.Shipping_Address,
    s.Delivery_Date
FROM Orders o
JOIN Shipping s
    ON o.Order_ID = s.Order_ID;
    
-- Shopping Cart → Product
SELECT
    c.Customer_ID,
    c.Name AS Customer_Name,
    sc.Cart_ID,
    p.Product_ID,
    p.Product_Name,
    sc.Quantity,
    sc.Total_Price,
    sc.Cart_Status
FROM Customer c
JOIN shoppingcart sc
    ON c.Customer_ID = sc.Customer_ID
JOIN Product p
    ON sc.Product_ID = p.Product_ID;
    
-- Customer → Review → Product
SELECT
    c.Customer_ID,
    c.Name AS Customer_Name,
    p.Product_ID,
    p.Product_Name,
    r.Review_ID,
    r.Rating,
    r.Review_Text,
    r.Review_Date,
    r.Status
FROM Customer c
JOIN Review r
    ON c.Customer_ID = r.Customer_ID
JOIN Product p
    ON r.Product_ID = p.Product_ID;
    
-- left join
SELECT
    c.Customer_ID,
    c.Name AS Customer_Name,

    o.Order_ID,
    o.Order_Date,
    o.Total_Amount,
    o.Shipping_Status,

    p.Payment_ID,
    p.Payment_Date,
    p.Amount AS Payment_Amount,
    p.Bank_Name,

    s.Shipping_ID,
    s.Shipping_Address,
    s.Delivery_Date

FROM Customer c

JOIN Orders o
    ON c.Customer_ID = o.Customer_ID

LEFT JOIN Payment p
    ON o.Order_ID = p.Order_ID

LEFT JOIN Shipping s
    ON o.Order_ID = s.Order_ID;